<link rel="stylesheet" href="main.css" />
<div class="nav">
    <ul>
        <li><a href="\server-projects\Actividad 1\index.php">Personal data</a></li>
        <li><a href="\server-projects\Actividad 1\skills.php">Skills</a></li>
        <li><a href="\server-projects\Actividad 1\works_done.php">Works done</a></li>
        <li><a href="\server-projects\Actividad 1\hobbies.php">Hobbies</a></li>
    </ul>
</div>