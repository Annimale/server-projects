<link rel="stylesheet" href="main.css" />
<div class="nav">
    <ul>
        <li><a href="index.php">Personal data</a></li>
        <li><a href="skills.php">Skills</a></li>
        <li><a href="works_done.php">Works done</a></li>
        <li><a href="hobbies.php">Hobbies</a></li>
    </ul>
</div>